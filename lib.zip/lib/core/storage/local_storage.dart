// lib/core/storage/local_storage.dart
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'session_data.dart';

class LocalStorage {
  static final LocalStorage instance = LocalStorage._internal();
  final FlutterSecureStorage _secureStorage = const FlutterSecureStorage();

  LocalStorage._internal();

  Future<void> saveSession(String dni, String token) async {
    await _secureStorage.write(key: 'dni', value: dni);
    await _secureStorage.write(key: 'token', value: token);
  }

  Future<SessionData?> readSession() async {
    final dni = await _secureStorage.read(key: 'dni');
    final token = await _secureStorage.read(key: 'token');

    if (dni != null && token != null) {
      return SessionData(dni: dni, token: token);
    }
    return null;
  }

  Future<void> clear() async {
    await _secureStorage.delete(key: 'dni');
    await _secureStorage.delete(key: 'token');
  }
}
