// lib/core/storage/session_data.dart
class SessionData {
  final String dni;
  final String token;

  const SessionData({required this.dni, required this.token});
}
