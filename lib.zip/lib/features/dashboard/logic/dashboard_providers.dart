import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final empleadoProvider = FutureProvider.family<Map<String, dynamic>, String>((ref, dni) async {
  final dio = Dio();
  final token = await getToken(); // Asegurate de implementar esto

  print('Consultando KPI con DNI real: $dni');

  final Response<Map<String, dynamic>> response = await dio.get<Map<String, dynamic>>(
    'https://appdelpalacio.onrender.com/api/kpis_por_dni/$dni',
    options: Options(
      headers: {
        'Accept': 'application/json',
        'Authorization': 'Bearer $token',
      },
    ),
  );

  if (response.statusCode == 200) {
    return response.data ?? {}; // devuelvo data o mapa vacío
  } else {
    throw Exception('Error al cargar KPIs del empleado');
  }
});
