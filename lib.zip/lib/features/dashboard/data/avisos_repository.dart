import 'dart:convert';
import 'aviso.dart';

class AvisosRepository {
  final String baseUrl;

  AvisosRepository({this.baseUrl = 'https://appdelpalacio.onrender.com'});

  Future<List<Aviso>> getAvisos(String dni) async {
    if (dni.trim().isEmpty) {
      throw Exception('DNI no válido');
    }

    final url = Uri.parse('$baseUrl/avisos/$dni');
    final response = await http.get(url);

    if (response.statusCode != 200) {
      throw Exception('Error al obtener avisos: ${response.body}');
    }

    final List<dynamic> data = jsonDecode(response.body);
    return data.map((json) => Aviso.fromJson(json)).toList();
  }
}





