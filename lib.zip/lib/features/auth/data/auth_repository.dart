
// lib/features/auth/data/auth_repository.dart
import 'package:dio/dio.dart';
import 'package:del_palacio_app/core/network/dio_client.dart';
import 'package:del_palacio_app/core/storage/local_storage.dart';
import 'package:del_palacio_app/features/auth/data/usuario_actual.dart';

/// Excepción específica para errores de autenticación.
class AuthFailure implements Exception {
  AuthFailure(this.message);
  final String message;

  @override
  String toString() => r'AuthFailure: $message';
}

/// Repositorio de autenticación: login, sesión y logout.
class AuthRepository {
  final LocalStorage _storage = LocalStorage.instance;

  UsuarioActual? _usuarioActual;
  UsuarioActual = usuarioActual(dni: session.dni); // ahora sí funciona

  /// POST `/login` y guarda sesión (dni + token).
  Future<void> login({required String dni}) async {
    try {
      final response = await dio.post<Map<String, dynamic>>(
        '/login',
        data: {'dni': dni},
      );

      final data = response.data;
      if (data == null) throw AuthFailure('Respuesta vacía del servidor');

      final success = data['success'] as bool? ?? false;
      if (!success) {
        final message = data['message'] as String? ?? 'Credenciales inválidas';
        throw AuthFailure(message);
      }

      final token = data['token'] as String?;
      if (token == null || token.isEmpty) {
        throw AuthFailure('Token no encontrado en la respuesta');
      }

      _usuarioActual = UsuarioActual.fromJson(data);

      await _storage.saveSession(dni, token);
    } on DioException catch (e) {
      final errorMessage = e.response?.data?['message'] as String? ??
          e.message ??
          'Error de red o del servidor';
      throw AuthFailure(errorMessage);
    } catch (e) {
      throw AuthFailure(r'Error inesperado: ${e.toString()}');
    }
  }

  /// Devuelve `true` si hay una sesión guardada.
  Future<bool> restoreSession() async =>
      (await _storage.readSession()) != null;

  /// Borra la sesión local (logout).
  Future<void> logout() async => _storage.clear();
}
